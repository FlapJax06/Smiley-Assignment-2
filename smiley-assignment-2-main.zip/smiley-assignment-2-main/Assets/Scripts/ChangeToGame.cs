using UnityEngine;
using UnityEngine.SceneManagement;

public class ChangeToGame : MonoBehaviour
{
    void OnMouseDown()
    {
        SceneManager.LoadScene("ActualGame");
    }
}
