using UnityEngine;

public class SpaceshipController : MonoBehaviour
{
    public Animator animator;  
  

    private void Update()
    {
        
        if (Input.GetKey(KeyCode.W))
        {
          
            animator.SetBool("ShipBooster", true);

      
        }
        else
        {
        
            animator.SetBool("ShipBooster", false);
        }
    }
}