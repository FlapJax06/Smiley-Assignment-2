using UnityEngine;

public class GamePause : MonoBehaviour
{
    private bool PauseTheGame = false;  // Track the game state (paused or not)
    public GameObject UI;

    void Update()
    {
        // Check if the P key is pressed
        if (Input.GetKeyDown(KeyCode.P))
        {
            // Toggle the pause state
            if (PauseTheGame)
            {
                Resume();  // If the game is paused, resume it
            }
            else
            {
                Pause();  // If the game is running, pause it
            }
        }
    }

    // Function to pause the game
    void Pause()
    {
        Time.timeScale = 0f;  // Freeze the game by setting time scale to 0
        PauseTheGame = true;  // Update the game state to paused
        UI.SetActive(true);
    }

    // Function to resume the game
    void Resume()
    {
        Time.timeScale = 1f;  // Set time scale back to 1 to resume the game
        PauseTheGame = false;  // Update the game state to running
        UI.SetActive(false);
    }
}


