using UnityEngine;

public class Sound4Fire : MonoBehaviour
{
    public AudioClip Fire; 
    private AudioSource audioSource;

    void Start()
    {
       
        audioSource = GetComponent<AudioSource>();
        if (audioSource == null)
        {
            audioSource = gameObject.AddComponent<AudioSource>();
        }
    }

    void Update()
    {
        // Check if the spacebar is pressed
        if (Input.GetKeyDown(KeyCode.Space))
        {
            PlayThePewPewSound();
        }
    }

    void PlayThePewPewSound()
    {
        if (Fire != null)
        {
            audioSource.PlayOneShot(Fire);
        }
    }
}
