using UnityEngine;

public class EngineSoundScript : MonoBehaviour
{
    // Reference to the AudioSource component
    public AudioSource engineSound;

    // The key to trigger the engine sound
    public KeyCode AccelKey = KeyCode.W;

    // Whether the sound is playing
    private bool EngineActive = false;
    void Start()
    {

        if (engineSound != null)
        {
            engineSound.Stop();
        }
    }

    // Update is called once per frame
    void Update()
    {
       
        if (Input.GetKey(AccelKey))         // If W  key is being held down
        {
            if (!EngineActive)
            {
                // Play the sound 
                engineSound.Play();
                EngineActive  = true;
            }
        }
        else
        {
            if (EngineActive)
            {
                // Stop the sound after W key is released
                engineSound.Stop();
                EngineActive = false;
            }
        }
    }
}
