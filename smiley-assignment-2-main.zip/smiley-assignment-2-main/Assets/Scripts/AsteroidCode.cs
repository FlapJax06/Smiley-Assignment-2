using System.Collections;
using Unity.VisualScripting;
using UnityEngine;

public class Asteroid_Instantiate : MonoBehaviour
{



    public GameObject[] PrefabBullet;

    public Transform AsteroidShoot;

    public float AsteroidSpped;

   
    public float pause = 1.56f;

    // Start is called once before the first execution of Update after the MonoBehaviour is created



    void Start()
    {

        StartCoroutine(AsteroidLaunch());

    }

    //when bullet collides with asteroid

    private IEnumerator AsteroidLaunch()
    {
      while (true) 
        {

            Quaternion Rotation = Quaternion.Euler(0f, 0f, Random.Range(0, 360));

            var Rounds = Instantiate(PrefabBullet[0], AsteroidShoot.position, Rotation); 
            Vector3 AsteroidShootP = new Vector3(Random.Range(3f, -2f), Random.Range(9f, 6f), 0).normalized;

            Rigidbody2D Velocity = Rounds.GetComponent<Rigidbody2D>();
            Velocity.velocity = -AsteroidShootP * AsteroidSpped;
   
           

            yield return new WaitForSeconds(pause);
        }
    }
    

}