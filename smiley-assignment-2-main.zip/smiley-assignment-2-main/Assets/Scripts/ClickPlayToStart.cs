using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClickPlayToStart : MonoBehaviour
{


    public Animator Animation;
 
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Mouse1))
        {
            Animation.SetBool("Play Button Bool ", true);
        }
        else {Animation.SetBool("Play Button Bool", false);
                }
        }
    }

