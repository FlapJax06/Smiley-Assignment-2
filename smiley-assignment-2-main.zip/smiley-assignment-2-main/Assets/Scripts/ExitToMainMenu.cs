using UnityEngine;
using UnityEngine.SceneManagement;

public class ExitToMainMenu : MonoBehaviour
{
  public void OnMouseDown()
    {
        SceneManager.LoadScene("Start2");
    }
}
