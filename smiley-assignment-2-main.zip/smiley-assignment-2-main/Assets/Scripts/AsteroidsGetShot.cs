using UnityEngine;

public class Bullet_Collision : MonoBehaviour
{





    public GameObject ExplosionVfxPrefab;

    public Transform Vfx_Start;



    public int damage = 0;
    public int NoOfVfx = 1;

    void Start()
    {

    }
    public void OnTriggerEnter2D(Collider2D collision)
    {

        if (collision.gameObject != null)
        {
            if (collision.gameObject.CompareTag("Asteroid"))
            {

                Debug.Log("AsteroidGotHit!");
                Destroy(gameObject);
                Destroy(collision.gameObject);
            

            }


        }
    }
}
